import os
from django.core.wsgi import get_wsgi_application
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'slqs_ksa_web.settings')
application = get_wsgi_application()
